#ifndef __MY_MAX_H_
#define __MY_MAX_H_

int	my_max(int itab[], int len);
int	*create_list(int nb_elem, char **nb);

#endif /* __MY_MAX_H_ */
